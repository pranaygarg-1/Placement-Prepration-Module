#include <bits/stdc++.h>
using namespace std;
int main()
 {
     int i,n;
     string s;
     cin>>s;
     n=s.length();
 for(i=0;i<n;i++)
     {
          if(ch!='{' && ch!='}' && ch!=" ")
         {
          t++;
         }
     }
         
     for( char j=='a';j<='z';j++)
      {
     for(i=0;i<n;i++)
     {
         char ch = s[i];;
         if(ch!='{' && ch!='}' && ch!=" ")
         {
             
                 if(ch==j)
                 {
                     f++;
                 }
         }
      }
      if(f>1)
      
     }
 }
