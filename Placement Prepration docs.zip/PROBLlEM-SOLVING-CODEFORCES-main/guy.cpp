#include <bits/stdc++.h>
using namespace std;
int main()
{
    int i,a;
    vector <int> p;
    vector <int> q;
    for(i=0;i<p.size();i++)
    {
        cin>>a;
         p.push_back(a);
        
    }
    for(i=0;i<q.size();i++)
    {
        
          cin>>a;
        q.push_back(i);
    }
}
